// let myString = 'Salom, dunyo!';
// console.log(myString.length); // 13





// let string1 = 'Salom, ';
// let string2 = 'dunyo!';
// let birlashtirilganString = string1 + string2;
// console.log(birlashtirilganString); // Salom, dunyo!

// let birlashtirilganString2 = string1.concat(string2);
// console.log(birlashtirilganString2); // Salom, dunyo!







// let myString = 'Salom, dunyo!';
// let qism1 = myString.slice(7, 12); // 'dunyo'
// let qism2 = myString.substring(7, 12); // 'dunyo'
// let qism3 = myString.substr(7, 5); // 'dunyo'
// console.log(qism1, qism2, qism3);







// let myString = 'Salom, dunyo!';
// let array = myString.split(', '); // ['Salom', 'dunyo!']
// console.log(array);












// let myString = 'Salom, dunyo!';
// let yangiString = myString.replace('dunyo', 'Oʻzbekiston');
// console.log(yangiString); // Salom, Oʻzbekiston!












// let myString = 'Salom, dunyo!';
// let indeks1 = myString.indexOf('dunyo'); // 7
// let indeks2 = myString.lastIndexOf('o'); // 10
// let mavjud = myString.includes('dunyo'); // true
// let indeks3 = myString.search('dunyo'); // 7
// console.log(indeks1, indeks2, mavjud, indeks3);














var string1 = '   Salom, dunyo!   ';
// let tozalanganString = myString.trim(); // 'Salom, dunyo!'
// console.log(tozalanganString)
console.log(string1); // false

var string1 = 'Salom';
let string2 = 'Salom';
console.log(string1 == string2); // false
console.log(string1 === string2); // false
